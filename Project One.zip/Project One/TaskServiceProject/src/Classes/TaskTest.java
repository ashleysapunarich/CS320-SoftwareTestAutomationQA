package Classes;
/*
 * Ashley Sapunarich
 * SNHU
 * CS320
 * Module Four Milestone
 * November 23 2024
 */
import org.junit.*;
import org.junit.jupiter.api.Assertions;


public class TaskTest {
    @Test
    public void testCreateValidTask() {
        Task task = new Task("1", "Task 1", "Description 1");
        Assert.assertEquals("1", task.getTaskId());
        Assert.assertEquals("Task 1", task.getName());
        Assert.assertEquals("Description 1", task.getDescription());
    }
    
    @Test
    public void testTaskIDTooLong() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Task ("12345678901", "Task 1", "Description 1");
    	});
    }
    
    @Test
    public void testTaskIDNull() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Task (null, "Task 1", "Description 1");
    	});
    }
    
    @Test
    public void testNameTooLong() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Task ("12345", "this is too long to accept", "Description 1");
    	});
    }
    
    @Test
    public void testNameNull() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Task ("12345", null, "Description 1");
    	});
    }
    
    @Test
    public void testDescriptionTooLong() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Task ("12345", "Task 1", "How many words would be too long to fit into this description");
    	});
    }
    
    @Test
    public void testDescriptionNull() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Task ("12345", "Task 1", null);
    	});
    }
    
    @Test
    public void testSetNameTooLong() {
    	Task task = new Task("1", "Task 1", "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		task.setName("this is too long to accept");
    	});
    }
    
    @Test
    public void testSetNameNull() {
    	Task task = new Task("1", "Task 1", "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		task.setName(null);
    	});
    }
    
    @Test
    public void testSetName() {
    	Task task = new Task("1", "Task 1", "Description 1");
    	task.setName("Task 3");
    	Assert.assertEquals("Task 3", task.getName());
    	
    }
    
    @Test
    public void testSetDescriptionTooLong() {
    	Task task = new Task("1", "Task 1", "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		task.setDescription("How many words would be too long to fit into this description");
    	});
    }
    
    @Test
    public void testSetDescriptionNull() {
    	Task task = new Task("1", "Task 1", "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		task.setDescription(null);
    	});
    }
    
    @Test
    public void testSetDescription() {
    	Task task = new Task("1", "Task 1", "Description 1");
    	task.setDescription("This is acceptable");
    	Assert.assertEquals("This is acceptable", task.getDescription());
    	
    }
}
