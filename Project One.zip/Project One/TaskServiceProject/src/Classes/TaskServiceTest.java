package Classes;
/*
 * Ashley Sapunarich
 * SNHU
 * CS320
 * Module Four Milestone
 * November 23 2024
 */
import java.util.NoSuchElementException;
import org.junit.*;
import org.junit.jupiter.api.Assertions;
import Classes.Task;
import Classes.TaskService;


public class TaskServiceTest {
    private TaskService taskService;

    @Before
    public void testSetup() {
        taskService = new TaskService();
    }

    @Test
    public void testAddValidTask() {
    	Task task = new Task("1", "Task 1", "Description 1");
        taskService.addTask("1", "Task 1", "Description 1");
        Assertions.assertEquals("1", task.getTaskId());
    }
    
    @Test
    public void testAddInvalidTask() {
    	taskService.addTask("1", "Task 1", "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		taskService.addTask("1", "Task 1", "Description 1");
    	});
        
    }
    
    @Test
    public void testDeleteTask() {
    	Task task = new Task("1", "New Task", "New Description");
    	taskService.deleteTask("1");
    	Assertions.assertNull(null, task.getTaskId());
    }


    @Test
    public void testUpdateTask() {
    	Task task = new Task("1", "New Task", "New Description");
    	taskService.addTask("1", "Task 1", "Description 1");
    	taskService.updateTask("1", "New Task", "New Description");
    	Assertions.assertEquals("New Task", task.getName());
    	Assertions.assertEquals("New Description", task.getDescription());
    }
    
    @Test
    public void testUpdateTaskNull() {
    	taskService.addTask("1", "Task 1", "Description 1");
    	Assertions.assertThrows(NoSuchElementException.class, ()->{
    		taskService.updateTask(null, "New Task", "New Description");
    	});
    	
    }
}