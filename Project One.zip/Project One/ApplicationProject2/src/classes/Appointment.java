package classes;
import java.util.Date;
import java.util.Calendar;

public class Appointment {
    private final String appointmentId; 
    private Date appointmentDate;
    private String description;

    Date currentDate = new Date();
    Calendar calendar = Calendar.getInstance();
    Date date = calendar.getTime();
    
    		
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if(appointmentId == null || appointmentId.length() > 10) throw new IllegalArgumentException("Invalid Appointment ID");
        if(appointmentDate == null || appointmentDate.before(currentDate)) throw new IllegalArgumentException("Invalid Date");
        if(description == null || description.length() > 50) throw new IllegalArgumentException("Invalid Description");
        
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        if(appointmentDate == null || appointmentDate.before(currentDate)) throw new IllegalArgumentException("Invalid Date");
        this.appointmentDate = appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if(description == null || description.length() > 50) throw new IllegalArgumentException("Invalid Description");
        this.description = description;
    }

}