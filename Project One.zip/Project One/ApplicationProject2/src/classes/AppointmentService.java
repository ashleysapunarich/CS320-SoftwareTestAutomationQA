package classes;

import java.util.*;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();
    
    public void addAppointment(String appointmentId, Date appointmentDate, String description) {
        if(appointments.containsKey(appointmentId)) throw new IllegalArgumentException("Appointment ID already exists");
        appointments.put(appointmentId, new Appointment(appointmentId, appointmentDate, description));
    }
    
    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
    }
    
    public Map<String, Appointment> getAppointments(){
    	return appointments;
    }
}