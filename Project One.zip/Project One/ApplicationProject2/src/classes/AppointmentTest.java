package classes;
import java.util.Date;
import org.junit.*;
import org.junit.jupiter.api.Assertions;

public class AppointmentTest {
	
	Date currentDate = new Date();
	
    @Test
    public void testCreateValidAppoinment() {
        Appointment appointment = new Appointment("1", new Date(), "Description 1");
        Assert.assertEquals("1", appointment.getAppointmentId());
        Assert.assertEquals(new Date(), appointment.getAppointmentDate());
        Assert.assertEquals("Description 1", appointment.getDescription());
    }
    
   
	@Test
    public void testAppointmentIDTooLong() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Appointment ("12345678901", new Date(), "Description 1");
    	});
    }
    
   
    @Test
    public void testAppointmentIDNull() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Appointment (null, new Date(), "Description 1");
    	});
    }
    
    @Test
    public void testDateInPast() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Appointment ("12345", new Date(0), "Description 1");
    	});
    }
    
    @Test
    public void testDateNull() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Appointment ("12345", null, "Description 1");
    	});
    }
    
    @Test
    public void testDescriptionTooLong() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Appointment ("12345", new Date(), "How many words would be too long to fit into this description");
    	});
    }
    
    @Test
    public void testDescriptionNull() {
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		new Appointment ("12345", new Date(), null);
    	});
    }
    
    @Test
    public void testSetDateInPast() {
    	Appointment appointment = new Appointment("1", new Date(), "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		appointment.setAppointmentDate(new Date(0));
    	});
    }
    
    @Test
    public void testSetDateNull() {
    	Appointment appointment = new Appointment("1", new Date(), "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		appointment.setAppointmentDate(null);
    	});
    }
    
    @Test
    public void testSetDate() {
    	Appointment appointment = new Appointment("1", new Date(), "Description 1");
    	appointment.setAppointmentDate(new Date());
    	Assert.assertEquals(new Date(), appointment.getAppointmentDate());
    	
    }
    
    @Test
    public void testSetDescriptionTooLong() {
    	Appointment appointment = new Appointment("1", new Date(), "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		appointment.setDescription("How many words would be too long to fit into this description");
    	});
    }
    
    @Test
    public void testSetDescriptionNull() {
    	Appointment appointment = new Appointment("1", new Date(), "Description 1");
    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
    		appointment.setDescription(null);
    	});
    }
    
    @Test
    public void testSetDescription() {
    	Appointment appointment = new Appointment("1", new Date(), "Description 1");
    	appointment.setDescription("This is acceptable");
    	Assert.assertEquals("This is acceptable", appointment.getDescription());
    	
    }
}

