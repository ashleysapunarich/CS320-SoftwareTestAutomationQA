package classes;
import org.junit.*;
import java.util.Date;


public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    
    @Before
    public void setUp() {
        // Create a new instance of AppointmentService before each test
        appointmentService = new AppointmentService();
    }

    @SuppressWarnings("deprecation")
	@Test
    public void testAddAppointment() {
        // Test data
        String appointmentID = "1234567890";
        String description = "Test Appointment";

        // Add the appointment to the service
        appointmentService.addAppointment(appointmentID, new Date("25-July-2029") , description);

        // Check if the appointment was added successfully
        Assert.assertEquals(1, appointmentService.getAppointments().size());
    }

    @Test
    public void testDeleteAppointment() {
        // Test data
        String appointmentID = "1234567890";
        String description = "Test Appointment";
       

        // Add the appointment to the service
        appointmentService.addAppointment(appointmentID, new Date(), description);

        // Check if the appointment was added successfully
        Assert.assertEquals(1, appointmentService.getAppointments().size());

        // Delete the appointment using its ID
        appointmentService.deleteAppointment(appointmentID);

        // Check if the appointment was deleted successfully
        Assert.assertEquals(0, appointmentService.getAppointments().size());
    }
    
    @SuppressWarnings("deprecation")
	@Test
    public void testGetAppointments() {
    	appointmentService.addAppointment("1", new Date("1-May-2030"), "Description");
    	appointmentService.addAppointment("2", new Date("1-May-2030"), "Description");
    	appointmentService.addAppointment("3", new Date("1-May-2030"), "Description");
    	appointmentService.addAppointment("4", new Date("1-May-2030"), "Description");
    	appointmentService.addAppointment("5", new Date("1-May-2030"), "Description");
    	Assert.assertEquals(5, appointmentService.getAppointments().size());
    }
}