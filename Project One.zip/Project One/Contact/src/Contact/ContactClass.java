/***************
 * Ashley Sapunarich
 * CS320 Software Test, Automation QA
 * November 16 2024
 */
package Contact;

//Creating Fields for each Contact
public class ContactClass {
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String contactAddress;

	//Creating a Constructor
	public ContactClass(String contactID, String firstName, String lastName, String phoneNumber,
			String contactAddress) {
		if(contactID == null || contactID.length() > 10) throw new IllegalArgumentException("Invalid Contact ID");
	    if(firstName == null || firstName.length() > 10) throw new IllegalArgumentException("Invalid First Name");
	    if(lastName == null || lastName.length() > 10) throw new IllegalArgumentException("Invalid Last Name");
	    if(phoneNumber == null || phoneNumber.length() != 10) throw new IllegalArgumentException("Invalid Phone Number");
	    if(contactAddress == null || contactAddress.length() > 30) throw new IllegalArgumentException("Invalid Address");
	        
		this.contactID = contactID;
		this.setFirstName(firstName);
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.contactAddress = contactAddress;
	}
	
	//Creating setter and getter methods
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String LastName) {
		this.lastName = LastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String PhoneNumber) {
		this.phoneNumber = PhoneNumber;
	}
	
	public String getContactAddress() {
		return contactAddress;
	}
	
	public void setContactAddress(String ContactAddress) {
		this.contactAddress = ContactAddress;
	}

}
