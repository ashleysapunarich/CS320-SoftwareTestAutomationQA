package Contact;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
	
	//Testing adding a contact
	@Test
	public void testAddContact() {
		ContactService contactService = new ContactService();
		ContactClass contact = new ContactClass("1234567890", "Ashley", "Sap", "4849168246", "123 Galaxy Way");
		contactService.addContact(contact);
		
		assertEquals(contact, contactService.getContact("1234567890"));
	}
	
	
	
	//Testing updating a first name
	@Test
	public void testUpdateFirstName() {
		ContactService contactService = new ContactService();
		ContactClass contact = new ContactClass("1234567890", "Ashley", "Sap", "4849168246", "123 Galaxy Way");
		contactService.addContact(contact);
		contactService.updateFirstName("1234567890", "Ash");
		
		assertEquals("Ash", contactService.getContact("1234567890").getFirstName());
	}
	
	//Testing updating a last name
	@Test
	public void testUpdateLastName() {
		ContactService contactService = new ContactService();
		ContactClass contact = new ContactClass("1234567890", "Ashley", "Sap", "4849168246", "123 Galaxy Way");
		contactService.addContact(contact);
		contactService.updateLastName("1234567890", "Sapunarich");
		
		assertEquals("Sapunarich", contactService.getContact("1234567890").getLastName());
	}
	
	//Testing updating a phone number
	@Test
	public void testUpdatePhoneNumber() {
		ContactService contactService = new ContactService();
		ContactClass contact = new ContactClass("1234567890", "Ashley", "Sap", "4849168246", "123 Galaxy Way");
		contactService.addContact(contact);
		contactService.updatePhoneNumber("1234567890", "9086379954");
		
		assertEquals("9086379954", contactService.getContact("1234567890").getPhoneNumber());
	}
	
	//Testing updating a contact address
	@Test
	public void testUpdateContactAddress() {
		ContactService contactService = new ContactService();
		ContactClass contact = new ContactClass("1234567890", "Ashley", "Sap", "4849168246", "123 Galaxy Way");
		contactService.addContact(contact);
		contactService.updateContactAddress("1234567890", "51 Founders Way");
		
		assertEquals("51 Founders Way", contactService.getContact("1234567890").getContactAddress());
	}
}
