package Contact;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;

public class ContactTest {


	//Testing Contact Class
	@Test
	public void testContactCreation() {
		ContactClass contact = new ContactClass("1234567890", "Ashley", "Sap", "4849168246", "123 Galaxy Way");
		
		assertNotNull(contact);
		assertEquals("1234567890", contact.getContactID());
		assertEquals("Ashley", contact.getFirstName());
		assertEquals("Sap", contact.getLastName());
		assertEquals("4849168246", contact.getPhoneNumber());
		assertEquals("123 Galaxy Way", contact.getContactAddress());
	}
	
	 @Test
	    public void testContactIDTooLong() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("12345678901", "Ashley", "Sap", "4849168246", "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testContactIDNull() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass (null, "Ashley", "Sap", "4849168246", "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testFirstNameTooLong() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("01", "AshleyNicole", "Sap", "4849168246", "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testFirstNameNull() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("01", null, "Sap", "4849168246", "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testLastNameTooLong() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("01", "Ashley", "Sapunarich-Lopez", "4849168246", "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testLastNameNull() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
				ContactClass contact = new ContactClass ("01", "Ashley", null, "4849168246", "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testPhoneNumberNotTen() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("01", "Ashley", "Sapunarich", "484916", "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testPhoneNumberNull() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("01", "Ashley", "Sap", null, "123 Galaxy Way");
	    	});
	    }
	    
	    @Test
	    public void testAddressTooLong() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("01", "Ashley", "Sapunarich", "4849168246", "This is probably longer than 30 characters");
	    	});
	    }
	    
	    @Test
	    public void testAddressNull() {
	    	Assertions.assertThrows(IllegalArgumentException.class, ()->{
	    		@SuppressWarnings("unused")
	    		ContactClass contact = new ContactClass ("01", "Ashley", "Sap", "4849168246", null);
	    	});
	    }
}
