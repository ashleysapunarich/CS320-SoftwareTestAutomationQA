/***************
 * Ashley Sapunarich
 * CS320 Software Test, Automation QA
 * November 16 2024
 */
package Contact;
import java.util.HashMap;
import java.util.Map;


public class ContactService {
	private Map<String, ContactClass> contacts;
	
	public ContactService() {
		contacts = new HashMap<>();
	}
	
	public void addContact(ContactClass contact) {
		contacts.put(contact.getContactID(), contact);
	}
	
	public void deleteContact(String contactID) {
		contacts.remove(contactID);
	}
	
	//Cannot be null and cannot be more than 10 characters
	public void updateFirstName(String contactID, String newFirstName) {
		ContactClass contact = contacts.get(contactID);
		if (newFirstName != null && (newFirstName.length() < 11)) {
			contact.setFirstName(newFirstName);
		}
	}
	
	//Cannot be null and cannot be more than 10 characters
	public void updateLastName(String contactID, String newLastName) {
		ContactClass contact = contacts.get(contactID);
		if (newLastName != null && (newLastName.length() < 11)) {
			contact.setLastName(newLastName);
		}
	}
	
	//Cannot be null and must be 10 characters
	public void updatePhoneNumber(String contactID, String newPhoneNumber) {
		ContactClass contact = contacts.get(contactID);
		if (newPhoneNumber != null && (newPhoneNumber.length() == 10)) {
			contact.setPhoneNumber(newPhoneNumber);
		}
	}
	
	
	//Cannot be null and cannot be more than 30 characters
	public void updateContactAddress(String contactID, String newContactAddress) {
		ContactClass contact = contacts.get(contactID);
		if (newContactAddress != null && (newContactAddress.length() < 31)) {
			contact.setContactAddress(newContactAddress);
		}
	}
	
	public ContactClass getContact(String contactID) {
		return contacts.get(contactID);
	}
}
